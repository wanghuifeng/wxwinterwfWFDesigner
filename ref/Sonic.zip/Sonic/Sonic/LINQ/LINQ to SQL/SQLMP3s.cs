namespace Sonic
{
    partial class SQLMP3sDataContext
    {
    }
}
