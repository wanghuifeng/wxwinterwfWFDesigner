﻿
namespace XPence.Views
{
    /// <summary>
    /// Interaction logic for TransactionView.xaml
    /// </summary>
    public partial class TransactionView
    {
        public TransactionView()
        {
            InitializeComponent();
        }
    }
}
