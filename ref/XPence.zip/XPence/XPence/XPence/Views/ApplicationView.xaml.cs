﻿namespace XPence.Views
{
    /// <summary>
    /// Interaction logic for ApplicationView.xaml
    /// </summary>
    public partial class ApplicationView
    {
        public ApplicationView()
        {
            InitializeComponent();
        }
    }
}
