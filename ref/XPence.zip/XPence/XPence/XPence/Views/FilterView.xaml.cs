﻿
namespace XPence.Views
{
    /// <summary>
    /// Interaction logic for FilterView.xaml
    /// </summary>
    public partial class FilterView
    {
        public FilterView()
        {
            InitializeComponent();
        }
    }
}
