﻿
namespace XPence.Views
{
    /// <summary>
    /// Interaction logic for UserView.xaml
    /// </summary>
    public partial class UserView
    {
        public UserView()
        {
            InitializeComponent();
        }
    }
}
