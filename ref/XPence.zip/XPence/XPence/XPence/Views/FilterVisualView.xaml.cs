﻿
namespace XPence.Views
{
    /// <summary>
    /// Interaction logic for FilterVisualView.xaml
    /// </summary>
    public partial class FilterVisualView
    {
        public FilterVisualView()
        {
            InitializeComponent();
        }
    }
}
