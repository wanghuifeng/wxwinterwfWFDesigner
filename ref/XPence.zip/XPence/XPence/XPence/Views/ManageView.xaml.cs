﻿

namespace XPence.Views
{
    /// <summary>
    /// Interaction logic for ManageView.xaml
    /// </summary>
    public partial class ManageView
    {
        public ManageView()
        {
            InitializeComponent();
        }
    }
}
