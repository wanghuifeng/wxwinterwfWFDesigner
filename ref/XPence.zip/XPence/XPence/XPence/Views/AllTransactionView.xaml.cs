﻿
namespace XPence.Views
{
    /// <summary>
    /// Interaction logic for AllTransactionView.xaml
    /// </summary>
    public partial class AllTransactionView
    {
        public AllTransactionView()
        {
            InitializeComponent();
        }
    }
}
