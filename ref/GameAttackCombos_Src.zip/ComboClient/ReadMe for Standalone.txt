- Game Attack Combos standalone application
-   from http://www.codeproject.com/KB/smart/GameAttackCombos.aspx

* Requirements:
  - .NET Framework 3.5 with SP1 
    (http://www.microsoft.com/downloads/details.aspx?FamilyId=AB99342F-5D1A-413D-8319-81DA479AB0D7&displaylang=en)


1.) Unzip all files into the folder of your choice and run GameAttackCombos.exe.
2.) Enjoy!