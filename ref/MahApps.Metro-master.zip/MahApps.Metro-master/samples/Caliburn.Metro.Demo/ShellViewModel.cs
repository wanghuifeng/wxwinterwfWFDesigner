namespace Caliburn.Metro.Demo {
    public class ShellViewModel : IShell {}
}