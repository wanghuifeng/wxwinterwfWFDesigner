﻿namespace MetroDemo.ExampleWindows
{
    public partial class VSDemo
    {
        public VSDemo()
        {
            InitializeComponent();
        }
    }
}