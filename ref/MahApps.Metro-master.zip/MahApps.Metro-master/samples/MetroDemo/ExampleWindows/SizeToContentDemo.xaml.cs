﻿using System;
using MahApps.Metro.Controls;

namespace MetroDemo.ExampleWindows
{
    /// <summary>
    /// Interaction logic for SizeToContentDemo.xaml
    /// </summary>
    public partial class SizeToContentDemo : MetroWindow
    {
        public SizeToContentDemo()
        {
            InitializeComponent();
        }
    }
}
