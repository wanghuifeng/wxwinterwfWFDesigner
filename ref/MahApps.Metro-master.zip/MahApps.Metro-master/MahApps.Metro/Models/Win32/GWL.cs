﻿
namespace MahApps.Metro.Models.Win32
{
	enum GWL : int
	{
		STYLE = -16,
		EXSTYLE = -20,
	}
}
