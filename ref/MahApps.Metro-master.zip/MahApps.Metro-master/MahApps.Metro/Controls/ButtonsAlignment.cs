﻿namespace MahApps.Metro.Controls
{
   public enum ButtonsAlignment
   {
      Left,
      Right
   }
}
