﻿namespace MahApps.Metro.Tests
{
    public partial class FlyoutWindow
    {
        public FlyoutWindow()
        {
            InitializeComponent();
        }
    }
}
