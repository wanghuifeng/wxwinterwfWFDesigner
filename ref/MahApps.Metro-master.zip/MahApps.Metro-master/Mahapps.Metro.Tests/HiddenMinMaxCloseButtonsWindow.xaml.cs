﻿namespace MahApps.Metro.Tests
{
    public partial class HiddenMinMaxCloseButtonsWindow
    {
        public HiddenMinMaxCloseButtonsWindow()
        {
            InitializeComponent();
        }
    }
}
