﻿namespace MahApps.Metro.Tests
{
    public partial class ButtonWindow
    {
        public ButtonWindow()
        {
            InitializeComponent();
        }
    }
}
