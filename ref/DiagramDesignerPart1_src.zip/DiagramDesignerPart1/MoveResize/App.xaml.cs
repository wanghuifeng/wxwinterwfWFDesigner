﻿using System.Windows;

namespace DiagramDesigner
{
    public partial class App : Application
    {
    }
}
