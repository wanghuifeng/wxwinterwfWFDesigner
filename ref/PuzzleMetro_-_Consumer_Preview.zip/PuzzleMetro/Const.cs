﻿namespace PuzzleMetro
{
    public class Const
    {
        public const string TimeFormat = "{0:00}:{1:00}:{2:00}";
        public const string DefaultTimeValue = "00:00:00";
        public const string DownloadLink = "http://tinyuri.com/MetroPuzzle";
    }
}
